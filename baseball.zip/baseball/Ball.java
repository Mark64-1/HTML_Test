package baseball;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Ball {

    int strike;
    int ball;

    public Ball(int input, int call, result mine) {
        List<Integer> results = mine.getResult();
        if (results.get(call) == input) {
            strike++;
            return;
        }
        for (int i = 0; i < 3; i++) {
            ballcheck(results, i, input);
        }

    }

    void ballcheck(List<Integer> l, int data, int input) {
        if (l.get(data) == input) {
            ball++;
            return;
        }
    }

    int getStrike() {
        return strike;
    }

    int getBall() {
        return ball;
    }
}
