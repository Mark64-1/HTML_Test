package baseball;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class baseball {

    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        result rs = new result();
        int myContinue = 0;
        while (myContinue != 2) {
            System.out.println(rs.getResult());
            myData my = getInput(rs);
            my.printResult();
            myContinue = my.checkGameEnd();
            rs.newResult(myContinue);
        }
    }

    static myData getInput(result mine) {
        System.out.println("숫자 3글자를 입력해주세요 ->");
        String temp = scan.next();
        while(inputCheck(temp)){
            temp=scan.next();
        }
        myData my = new myData();
        for (int i = 0; i < temp.length(); i++) {
            Ball b = new Ball(Integer.parseInt(temp.charAt(i) + ""), i, mine);
            my.setStrike(b.getStrike());
            my.setball(b.getBall());
        }
        return my;
    }

    static boolean inputCheck(String input){
        try{
            int q = Integer.parseInt(input);
        }catch (Exception e){
            System.out.println("숫자를 입력해주세요.");
            return true;
        }
        if(input.length()!=3){
            System.out.println("3글자를 입력해주세요.");
            return true;
        }
        return false;
    }

}
