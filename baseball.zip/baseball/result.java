package baseball;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class result {

    HashSet<Integer> results = new HashSet<Integer>();

    public result() {
        while (results.size() != 3) {
            results.add((int) (Math.random() * 9) + 1);
        }
    }

    void newResult(int choice){
        List result =getResult();
        if(choice==1){
            results.remove(result.get(0));
            results.remove(result.get(1));
            results.remove(result.get(2));
        }
        while (results.size() != 3) {
            results.add((int) (Math.random() * 9) + 1);
        }
    }


    List getResult() {
        return new ArrayList(results);
    }
}

