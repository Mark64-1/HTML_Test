package baseball;

import java.util.List;
import java.util.Scanner;

public class myData {

    int strike = 0;
    int ball = 0;
    Scanner scan = new Scanner(System.in);

    public myData() {
        this.strike = 0;
        this.ball = 0;
    }

    void setStrike(int strike) {
        this.strike += strike;
    }

    void setball(int ball) {
        this.ball += ball;
    }

    int getStrike() {
        return strike;
    }

    int getBall() {
        return ball;
    }

    void printResult() {
        if (strike != 0) {
            System.out.println("스트라이크 : " + strike);
        }
        if (ball != 0) {
            System.out.println("볼 : " + ball);
        }
        if (ball == 0 && strike == 0) {
            System.out.println("포볼입니다!");
        }
    }

    int checkGameEnd() {
        if (strike != 3) {
            return 0;
        }
        return scan();
    }

    int scan(){
        System.out.println("모두 맞추셨습니다. 계속 하시려면 1, 아니라면 2를 입력해 종료하십시오.");
        int wily = scan.nextInt();
        if (wily == 1){
            return 1;
        }
        if (wily == 2){
            return 2;
        }
        return 0;
    }
}
